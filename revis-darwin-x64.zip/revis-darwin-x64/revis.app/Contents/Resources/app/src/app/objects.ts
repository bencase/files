export class TabProps {
	public connName: string;
}