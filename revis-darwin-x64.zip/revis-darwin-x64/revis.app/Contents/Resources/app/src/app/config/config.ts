export enum KeyType {
	String = "string",
	List = "list",
	Set = "set",
	Zset = "zset",
	Hash = "hash"
}